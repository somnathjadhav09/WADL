import './App.css';
import StudentList from './components/StudentList';

function App() {
  return (
    <div className="App">
       <StudentList/>
    </div>
  );
}

export default App;
